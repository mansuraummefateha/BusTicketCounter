﻿using BusTicketCounter_App.Models;
using Microsoft.Win32;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Path = System.IO.Path;

namespace BusTicketCounter_App
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public string filename = @"BusTicket.json";
        public FileInfo TempImageFile { get; set; }
        public BitmapImage DefaultImage => new BitmapImage(new Uri(GetImagePath() + "default.png"));

        public MainWindow()
        {
            InitializeComponent();
            
            string[] gender = new string[] { "Male", "Female" };
            this.cmbGender.ItemsSource = gender;
            cmbGender.SelectedIndex = -1;


            var path = Path.GetDirectoryName(GetImagePath());
            if (!File.Exists(filename))
            {
                File.CreateText(filename).Close();
            }
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            ImgDisplay.Source = DefaultImage;
            ShowData();

        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {

            BusTicket bt = new BusTicket()
            {
                ImageTitle = (TempImageFile != null) ? $"{int.Parse(txtId.Text) + TempImageFile.Extension}" : "default.png",
                Id = int.Parse(txtId.Text),
                FirstName=txtFirstName.Text,
                LastName = txtLastName.Text,
                Father = txtFather.Text,
                Mother=txtMother.Text,
                Age=txtAge.Text,
                Gender = cmbGender.SelectedItem.ToString(),
                Email = txtEmail.Text,
                Contact = txtContactNo.Text,
                NID=txtNID.Text,
                Address=txtAddress.Text,
                Date = txtDate.Text
            };

            string filedata = File.ReadAllText(filename);
            if (IsValidJson(filedata) && IsExists("BusTicket") && !IsIdExists(bt.Id))
            {
                var data = JObject.Parse(filedata);
                var btJson = data.GetValue("BusTicket").ToString();
                var btList = JsonConvert.DeserializeObject<List<BusTicket>>(btJson);
                btList.Add(bt);
                JArray btArray = JArray.FromObject(btList);
                data["BusTicket"] = btArray;
                var newJsonResult = JsonConvert.SerializeObject(data, Formatting.Indented);

                if (TempImageFile != null)
                {
                    TempImageFile.CopyTo(GetImagePath() + bt.ImageTitle);
                    TempImageFile = null;
                    ImgDisplay.Source = DefaultImage;
                }
                File.WriteAllText(filename, newJsonResult);
            }

            if (!IsValidJson(filedata))
            {
                var btp = new { BusTicket = new BusTicket[] { bt } };
                string newJsonResult = JsonConvert.SerializeObject(btp, Formatting.Indented);
                if (TempImageFile != null)
                {
                    TempImageFile.CopyTo(GetImagePath() + bt.ImageTitle);
                    TempImageFile = null;
                    ImgDisplay.Source = DefaultImage;
                }
                File.WriteAllText(filename, newJsonResult);
            }
            ShowData();
            AllClear();
        }
        private bool IsIdExists(int inputId)
        {
            string filedata = File.ReadAllText(filename);
            var data = JObject.Parse((string)filedata);
            var btJson = data.GetValue("BusTicket").ToString();
            var btList = JsonConvert.DeserializeObject<List<BusTicket>>(btJson);

            var exists = btList.Find(x => x.Id == inputId);

            if (exists != null)
            {
                MessageBox.Show($"ID - {exists.Id} exists\nTry with different Id", "Message", MessageBoxButton.OK, MessageBoxImage.Warning);
                return true;
            }
            else
            {
                return false;
            }

        }

        private bool IsValidJson(string data)
        {

            try
            {
                var tbt = JObject.Parse(data);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        private bool IsExists(string data)
        {
            string filedata = File.ReadAllText(filename);
            var jsonObject = JObject.Parse(filedata);
            var btJson = jsonObject[data];

            return (btJson != null) ? true : false;
        }

        private void Update_Click(object sender, RoutedEventArgs e)
        {
            Update update = new Update();
            update.Show();
            update.Owner = this;

            Button b = sender as Button;
            BusTicket btbtn = b.CommandParameter as BusTicket;

            update.txtId.IsEnabled = false;
            update.txtId.Text = btbtn.Id.ToString();
            update.txtFirstName.Text = btbtn.FirstName;
            update.txtLastName.Text = btbtn.LastName;
            update.txtFather.Text = btbtn.Father;
            update.txtMother.Text = btbtn.Mother;
            update.cmbGender.Text = btbtn.Gender;
            update.txtAge.Text = btbtn.Age;
            update.txtEmail.Text = btbtn.Email;
            update.txtContactNo.Text = btbtn.Contact;
            update.txtNID.Text = btbtn.NID;
            update.txtDate.Text = btbtn.Date;
            update.txtAddress.Text = btbtn.Address;
            update.ImgModify.Source = btbtn.ImageSrc;
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            var jsonD = File.ReadAllText(filename);
            var jsonObj = JObject.Parse(jsonD);
            var btJson = jsonObj.GetValue("BusTicket").ToString();
            var btList = JsonConvert.DeserializeObject<List<BusTicket>>(btJson);

            Button b = sender as Button;
            BusTicket btbtn = b.CommandParameter as BusTicket;
            int btId = btbtn.Id;

            MessageBoxResult result = MessageBox.Show($"Are you want to delete ID - {btId}", "Delete", MessageBoxButton.YesNo, MessageBoxImage.Warning);

            if (result == MessageBoxResult.Yes)
            {
                btList.Remove(btList.Find(x => x.Id == btId));
                JArray btArray = JArray.FromObject(btList);
                jsonObj["BusTicket"] = btArray;
                var newJsonResult = JsonConvert.SerializeObject(jsonObj, Formatting.Indented);

                FileInfo thisFile = new FileInfo(GetImagePath() + btbtn.ImageTitle);
                if (thisFile.Name != "default.png")
                {
                    thisFile.Delete();
                }

                File.WriteAllText(filename, newJsonResult);

                MessageBox.Show("Data Deleted Successfully !!", "Delete", MessageBoxButton.OK, MessageBoxImage.Question);
                ShowData();
                AllClear();
            }
            else
            {
                return;
            }
        }

        private void btnShowAll_Click(object sender, RoutedEventArgs e)
        {
            ShowData();
          
          
        }
        public void ShowData()
        {
            var json = File.ReadAllText(filename);

            if (!IsValidJson(json))
            {
                return;
            }

            var jsonObj = JObject.Parse(json);
            var btJson = jsonObj.GetValue("BusTicket").ToString();
            var btList = JsonConvert.DeserializeObject<List<BusTicket>>(btJson);
            btList = btList.OrderBy(x => x.Id).ToList();

            foreach (var item in btList)
            {
                item.ImageSrc = ImageInstance(new Uri(GetImagePath() + item.ImageTitle));
            }
            lstBusTicket.ItemsSource = btList;
            lstBusTicket.Items.Refresh();

            GC.Collect();
            GC.WaitForPendingFinalizers();
        }
        public ImageSource ImageInstance(Uri path)
        {
            BitmapImage bitmap = new BitmapImage();
            bitmap.BeginInit();
            bitmap.UriSource = path;
            bitmap.CacheOption = BitmapCacheOption.OnLoad;
            bitmap.CreateOptions = BitmapCreateOptions.IgnoreImageCache;
            bitmap.DecodePixelWidth = 300;
            bitmap.EndInit();
            bitmap.Freeze();
            return bitmap;
        }
        public string GetImagePath()
        {
            var currentAssembly = System.Reflection.Assembly.GetExecutingAssembly();
            string assemblyDirectory = Path.GetDirectoryName(currentAssembly.Location);
            string ImagePath = Path.GetFullPath(Path.Combine(assemblyDirectory, @"..\..\Img\"));

            return ImagePath;
        }

        private void btnUpload_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog fd = new OpenFileDialog();
            fd.Filter = "Image Files(*.jpg; *.jpeg; *.png)|*.jpg; *.jpeg; *.png;";
            fd.Title = "Select an Image";
            if (fd.ShowDialog().Value == true)
            {
                ImgDisplay.Source = new BitmapImage(new Uri(fd.FileName));
                TempImageFile = new FileInfo(fd.FileName);
            }
        }
        public void AllClear()
        {
            txtId.Clear();
  
            txtFirstName.Clear();
            txtLastName.Clear();
            txtFather.Clear();
            txtMother.Clear();
            txtAge.Clear();
            txtAge.Clear();
            txtAddress.Clear();
            cmbGender.SelectedIndex = -1;
            txtEmail.Clear();
            txtContactNo.Clear();
            txtNID.Clear();
            //txtDate.Clear();
            txtId.IsEnabled = true;
        }

        private void Details_Click(object sender, RoutedEventArgs e)
        {
           
          
            Button b = sender as Button;
            BusTicket btbtn = b.CommandParameter as BusTicket;
            txtView.Text =      $"  ID No    :\t\t{ btbtn.Id}\n" + $"  First Name:\t\t{btbtn.FirstName}\n" + $"  Last Name:\t\t{btbtn.LastName}\n" + $"  Father Name:\t\t{btbtn.Father}\n" +
            $"  Mother Name:\t\t{btbtn.Mother}\n"+ $"  Age:        \t\t{btbtn.Age}\n " + $" Gender:\t\t{btbtn.Gender}\n" + $"  ContactNo:    \t\t{btbtn.Contact}\n" + $"  Email:    \t\t{btbtn.Email}\n " +
            $" NID:        \t\t{btbtn.NID}\n" + $"  Address:\t\t{btbtn.Address}\n" + $"  DateTime:    \t\t{btbtn.Date}";
            ImageBox.Source = new BitmapImage(new Uri(GetImagePath() + btbtn.ImageTitle));
            
        }

        private void bntClose_Click(object sender, RoutedEventArgs e)
        {


        }
    }
}
