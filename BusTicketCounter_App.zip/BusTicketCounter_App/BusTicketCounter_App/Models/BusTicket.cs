﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Media;

namespace BusTicketCounter_App.Models
{
   public class BusTicket
    {
        public ImageSource ImageSrc { get; set; }
        public string ImageTitle { get; set; }
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Father { get; set; }
        public string Mother { get; set; }
        public string Address { get; set; }
        public string  Age { get; set; }
        public string NID { get; set; }
        public string Gender { get; set; }
        public string Email { get; set; }
        public string Contact { get; set; }
        public string Date { get; set; }
    }
}
