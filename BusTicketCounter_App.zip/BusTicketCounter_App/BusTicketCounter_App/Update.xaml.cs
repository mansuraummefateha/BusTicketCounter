﻿using BusTicketCounter_App.Models;
using Microsoft.Win32;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BusTicketCounter_App
{
    /// <summary>
    /// Interaction logic for Update.xaml
    /// </summary>
    public partial class Update : Window
    {
        public MainWindow mainWindow => (MainWindow)Owner;

        public string filename = @"BusTicket.json";
        

        public FileInfo TempImageFile { get; set; }
        public FileInfo OldImageFile { get; set; }
        public Update()
        {
            InitializeComponent();
            
            string[] gender = new string[] { "Male", "Female" };
            this.cmbGender.ItemsSource = gender;
            cmbGender.SelectedIndex = -1;

        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            var Id = Convert.ToInt32(txtId.Text);
            var FirstName = txtFirstName.Text;
            var LastName = txtLastName.Text;
            var Father = txtFather.Text;
            var Mother = txtMother.Text;
            var Gender = cmbGender.SelectedItem.ToString();
            var Age = txtAge.Text;
            var NID = txtNID.Text;
            var Address = txtAddress.Text;
            var Email = txtEmail.Text;
            var Contact = txtContactNo.Text;
            //var Date = txtDate.Text;

            var json = File.ReadAllText(filename);
            var jsonObj = JObject.Parse(json);
            var btJson = jsonObj.GetValue("BusTicket").ToString();
            var btList = JsonConvert.DeserializeObject<List<BusTicket>>(btJson);

            foreach (var item in btList.Where(x => x.Id == Id))
            {
                item.FirstName = FirstName;
                item.LastName = LastName;
                item.Father = Father;
                item.Mother = Mother;
                item.Gender = Gender;
                item.Age = Age;
                item.Email = Email;
                item.Contact = Contact;
                item.NID = NID;
                item.Address = Address;
                //item.Date = Date;
                OldImageFile = (item.ImageTitle != "default.png") ? new FileInfo(mainWindow.GetImagePath() + item.ImageTitle) : null;

                if (TempImageFile != null && OldImageFile == null)
                {
                    TempImageFile.CopyTo(mainWindow.GetImagePath() + item.Id + TempImageFile.Extension);
                    item.ImageTitle = item.Id + TempImageFile.Extension;
                    TempImageFile = null;
                }
                if (OldImageFile != null && TempImageFile != null && File.Exists(OldImageFile.FullName))
                {
                    item.ImageTitle = item.Id + TempImageFile.Extension;
                    OldImageFile.Delete();
                    TempImageFile.CopyTo(mainWindow.GetImagePath() + Id + TempImageFile.Extension);
                    TempImageFile = null;
                }

            }

            var empArray = JArray.FromObject(btList);
            jsonObj["Employees"] = empArray;
            string output = JsonConvert.SerializeObject(jsonObj, Formatting.Indented);
            File.WriteAllText(filename, output);

            this.Close();
            mainWindow.ShowData();
            MessageBox.Show("Data Updated Successfully !!");

        }

        private void btnImgModify_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog fd = new OpenFileDialog();
            fd.Filter = "Image Files(*.jpg; *.jpeg; *.png;)|*.jpg; *.jpeg; *.png;";
            fd.Title = "Select an Image";
            if (fd.ShowDialog().Value == true)
            {
                ImgModify.Source = mainWindow.ImageInstance(new Uri(fd.FileName));
                TempImageFile = new FileInfo(fd.FileName);
            }
        }
    }
}
